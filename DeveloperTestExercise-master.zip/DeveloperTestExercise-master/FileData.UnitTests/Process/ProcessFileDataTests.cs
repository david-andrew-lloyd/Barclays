﻿namespace FileData.UnitTests.Process
{
    using Enums;
    using FileData.Process;
    using Tools;
    using FileData.Validators;
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;

    [TestClass]
    public class ProcessFileDataTests
    {
        private Mock<IArgumentValidator> _argumentValidator;
        private Mock<IFileDetails> _fileDetails;

        [TestInitialize]
        public void Initialize()
        {
            _argumentValidator = new Mock<IArgumentValidator>();
            _fileDetails = new Mock<IFileDetails>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            _argumentValidator.VerifyAll();
            _fileDetails.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorProcessFileDataNullArgumentValidator()
        {
            try
            {
                // ReSharper disable once ObjectCreationAsStatement
                new ProcessFileData(null, _fileDetails.Object);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: argumentValidator";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorProcessFileDataNullFileDetails()
        {
            try
            {
                // ReSharper disable once ObjectCreationAsStatement
                new ProcessFileData(_argumentValidator.Object, null);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: fileDetails";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void ProcessInvalidNumberOfArguments()
        {
            var processFileData = new ProcessFileData(_argumentValidator.Object, _fileDetails.Object);            
            var arguments = new [] { "arg1", "arg2", "arg3", "arg4" };
            _argumentValidator.Setup(x => x.ValidateNumberOfArguments(arguments)).Throws(new ArgumentException("Invalid number of expected arguments, expecting: 4 received: 2"));
            _argumentValidator.Verify(x => x.ValidateFileName(It.IsAny<string>()), Times.Never);
            _argumentValidator.Verify(x => x.ValidateFunction(It.IsAny<string>()), Times.Never);            
            processFileData.Process(arguments);
        }

        [TestMethod]
        public void ProcessInvalidFileName()
        {
            var processFileData = new ProcessFileData(_argumentValidator.Object, _fileDetails.Object);
            var arguments = new [] { "-s", "SomeInvalidFileName" };
            
            _argumentValidator.Setup(x => x.ValidateNumberOfArguments(arguments));
            _argumentValidator.Setup(x => x.ValidateFileName("SomeInvalidFileName")).Throws(new ArgumentException("filename does not appear to be in correct format: SomeInvalidFileName"));
            processFileData.Process(arguments);

            _argumentValidator.Verify(x => x.ValidateNumberOfArguments(arguments), Times.Once);
            _argumentValidator.Verify(x => x.ValidateFileName("SomeInvalidFileName"), Times.Once);
            _argumentValidator.Verify(x => x.ValidateFunction(It.IsAny<string>()), Times.Never);
        }

        [DataTestMethod]
        [DataRow(new [] { "-s", @"c:\temp\test.txt"}, FunctionType.Size, @"File name: c:\temp\test.txt - File Size: 256")]
        [DataRow(new [] { "--s", @"c:\temp\test.txt" }, FunctionType.Size, @"File name: c:\temp\test.txt - File Size: 256")]
        [DataRow(new [] { "/s", @"c:\temp\test.txt" }, FunctionType.Size, @"File name: c:\temp\test.txt - File Size: 256")]
        [DataRow(new [] { "--size", @"c:\temp\test.txt" }, FunctionType.Size, @"File name: c:\temp\test.txt - File Size: 256")]
        [DataRow(new [] { "-v", @"c:\temp\test.txt" }, FunctionType.Version, @"File name: c:\temp\test.txt - File Version: 1.5")]
        [DataRow(new [] { "--v", @"c:\temp\test.txt" }, FunctionType.Version, @"File name: c:\temp\test.txt - File Version: 1.5")]
        [DataRow(new [] { "/v", @"c:\temp\test.txt" }, FunctionType.Version, @"File name: c:\temp\test.txt - File Version: 1.5")]
        [DataRow(new [] { "--version", @"c:\temp\test.txt" }, FunctionType.Version, @"File name: c:\temp\test.txt - File Version: 1.5")]
        [DataRow(new [] { "-u", @"c:\temp\test.txt" }, FunctionType.Unknown, "Unable to process invalid function type: Unknown")]
        // According to the specification this should be invalid
        [DataRow(new [] { "-size", @"c:\temp\test.txt" }, FunctionType.Unknown, "Unable to process invalid function type: Unknown")]
        [DataRow(new [] { "/size", @"c:\temp\test.txt" }, FunctionType.Unknown, "Unable to process invalid function type: Unknown")]
        [DataRow(new [] { "-version", @"c:\temp\test.txt" }, FunctionType.Unknown, "Unable to process invalid function type: Unknown")]
        [DataRow(new [] { "/version", @"c:\temp\test.txt" }, FunctionType.Unknown, "Unable to process invalid function type: Unknown")]
        public void ProcessFileData(string[] arguments, FunctionType functionType, string expectedOutput)
        {
            var processFileData = new ProcessFileData(_argumentValidator.Object, _fileDetails.Object);
            var argumentType = arguments[0];
            var filename = arguments[1];
            
            _argumentValidator.Setup(x => x.ValidateNumberOfArguments(arguments));
            _argumentValidator.Setup(x => x.ValidateFileName(filename));
            _argumentValidator.Setup(x => x.ValidateFunction(argumentType)).Returns(functionType);

            if (functionType == FunctionType.Size)
                _fileDetails.Setup(x => x.Size(filename)).Returns(256);
            else if (functionType == FunctionType.Version)
                _fileDetails.Setup(x => x.Version(filename)).Returns("1.5");

            var consoleOutput = processFileData.Process(arguments);
            Assert.AreEqual(expectedOutput, consoleOutput);

            _argumentValidator.Verify(x => x.ValidateNumberOfArguments(arguments), Times.Once);
            _argumentValidator.Verify(x => x.ValidateFileName(filename), Times.Once);
            _argumentValidator.Verify(x => x.ValidateFunction(argumentType), Times.Once);

            if (functionType == FunctionType.Size)
                _fileDetails.Verify(x => x.Size(filename), Times.Once);
            else if (functionType == FunctionType.Version)
                _fileDetails.Verify(x => x.Version(filename), Times.Once);
            else if (functionType == FunctionType.Unknown)
            {
                _fileDetails.Verify(x => x.Size(filename), Times.Never);
                _fileDetails.Verify(x => x.Version(filename), Times.Never);
            }
        }
    }
}
