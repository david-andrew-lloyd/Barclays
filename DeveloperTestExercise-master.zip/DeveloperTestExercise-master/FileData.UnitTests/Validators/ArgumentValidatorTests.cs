﻿namespace FileData.UnitTests.Validators
{
    using Enums;
    using FileData.Validators;
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ArgumentValidatorTests
    {
        /// <summary>
        /// The number of arguments we expect in main from string[] args
        /// </summary>
        private const int NumberOfExpectedArguments = 2;

        /// <summary>
        /// Regex to check form for a valid file name
        /// </summary>
        private readonly string _validFileNameRegex = @"^[\w\-\. ]+$";

        /// <summary>
        /// Regex to check form for the given input function
        /// </summary>        
        private readonly string _validFunctionRegex = @"^(-s|--s|\/s|--size|-v|--v|\/v|--version)$";

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ConstructorArgumentValidatorNegativeNumberOfExpectedArguments()
        {
            try
            {
                // ReSharper disable once ObjectCreationAsStatement
                new ArgumentValidator(-1, _validFileNameRegex, _validFunctionRegex);
            }
            catch (Exception ex)
            {
                const string expectedError = "numberOfExpectedArguments cannot be less than zero: -1";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorArgumentValidatorNullValidFilenameRegex()
        {
            try
            {
                // ReSharper disable once ObjectCreationAsStatement
                new ArgumentValidator(NumberOfExpectedArguments, null, _validFunctionRegex);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: validFilenameRegex";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorArgumentValidatorNullValidFunctionRegex()
        {
            try
            {
                // ReSharper disable once ObjectCreationAsStatement
                new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, null);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: validFunctionRegex";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidateNumberOfArgumentsNullArguments()
        {
            try
            {
                var argumentValidator = 
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateNumberOfArguments(null);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: arguments";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateNumberOfArgumentsFailsExpectedNumberOfArguments()
        {
            try
            {
                var args = new [] { "--s" };
                var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateNumberOfArguments(args);
            }
            catch (Exception ex)
            {
                const string expectedError = "Invalid number of expected arguments, expecting: 2 received: 1";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void ValidateNumberOfArguments()
        {
            var args = new [] { "--s", @"c:\temp\test.txt" };
            var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

            // Does not throw exception if the validation passed
            argumentValidator.ValidateNumberOfArguments(args);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidateFileNameNullFilePath()
        {
            try
            {
                var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateFileName(null);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: filePath";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateFileNameInvalidFileNameCharacters()
        {
            const string filePath = @"c:\temp\test>.txt";

            try
            {                
                var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateFileName(filePath);
            }
            catch (Exception ex)
            {
                var expectedError = "fileName contains invalid characters: " + filePath;
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateFileNameInvalidFileName()
        {
            const string filePath = @"c:\temp\test'txt";

            try
            {
                var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateFileName(filePath);
            }
            catch (Exception ex)
            {
                var expectedError = "filename does not appear to be in correct format: " + filePath;
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void ValidateFileName()
        {
            const string filePath = @"c:\temp\test.txt";

            var argumentValidator = 
                 new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

             // Does not throw exception if the validation passed
            argumentValidator.ValidateFileName(filePath);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidateFunctionNullFunction()
        {
            try
            {
                var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateFunction(null);
            }
            catch (Exception ex)
            {
                var expectedError = "Value cannot be null." + Environment.NewLine + "Parameter name: function";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateFunctionInvalidFunction()
        {
            var unknownFunction = "--UnknownFunction";

            try
            {
                var argumentValidator =
                    new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

                argumentValidator.ValidateFunction(unknownFunction);
            }
            catch (Exception ex)
            {
                const string expectedError = "Unknown function: --UnknownFunction";
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [DataTestMethod]
        [DataRow("-s", FunctionType.Size)]
        [DataRow("--s", FunctionType.Size)]
        [DataRow("/s", FunctionType.Size)]
        [DataRow("--size", FunctionType.Size)]
        [DataRow("-v", FunctionType.Version)]
        [DataRow("--v", FunctionType.Version)]
        [DataRow("/v", FunctionType.Version)]
        [DataRow("--version", FunctionType.Version)]
        public void ValidateFunction(string function, FunctionType functionType)
        {
            var argumentValidator =
                new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, _validFunctionRegex);

            var actualFunctionType = argumentValidator.ValidateFunction(function);
            Assert.AreEqual(functionType, actualFunctionType);
        }

        [DataTestMethod]
        [DataRow("-u", FunctionType.Unknown)]
        [DataRow("--u", FunctionType.Unknown)]
        [DataRow("/u", FunctionType.Unknown)]
        [DataRow("--unknown", FunctionType.Unknown)]
        public void ValidateFunctionUnknown(string function, FunctionType functionType)
        {
            var validUnknownFunctionRegex = @"^(-|--|\/)(u|unknown)$";

            var argumentValidator =
                new ArgumentValidator(NumberOfExpectedArguments, _validFileNameRegex, validUnknownFunctionRegex);

            var actualFunctionType = argumentValidator.ValidateFunction(function);
            Assert.AreEqual(functionType, actualFunctionType);
        }
    }
}
