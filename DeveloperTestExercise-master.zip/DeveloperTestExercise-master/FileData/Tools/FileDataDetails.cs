﻿namespace FileData.Tools
{
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    /// A way of extending ThirdPartyTools.FileDetails to implement the interface IFileDetails
    /// without changing the code at source. This way we have an implementation that is programmed
    /// to an iterface as opposed to a concrete type, the object at runtime is generated in the
    /// given unity container thereby following the principles for SOLID and LISKOV subsitution
    /// i.e. we can import other 3rd party tools providing they conform to the interface IFileDetails
    /// </summary>
    [ExcludeFromCodeCoverage]
    public sealed class FileDataDetails : ThirdPartyTools.FileDetails, IFileDetails
    {

    }
}
