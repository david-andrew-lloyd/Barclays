﻿namespace FileData.Tools
{
    /// <summary>
    /// Interface for ThirdPartyTools.FileDetails but this is essentially overidden 
    /// in this implementation since we cannot change ThirdPartyTools at source.
    /// </summary>
    public interface IFileDetails
    {
        /// <summary>
        /// Returns the version of the given file in filePath
        /// </summary>
        /// <param name="filePath">The full filename</param>
        /// <returns>Version</returns>
        string Version(string filePath);

        /// <summary>
        /// Returns the size of the given file in filePath
        /// </summary>
        /// <param name="filePath">The full filename</param>
        /// <returns>Size</returns>
        int Size(string filePath);
    }
}
