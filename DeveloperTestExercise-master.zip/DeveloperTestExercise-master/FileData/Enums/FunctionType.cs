﻿namespace FileData.Enums
{
    /// <summary> 
    /// Enum for FunctionType so its behaviour can be inerpreted consistently
    /// throughout the application at runtime
    /// </summary>
    public enum FunctionType { Size, Version, Unknown };
}
