﻿namespace FileData.Process
{
    using Enums;
    using System;
    using Tools;
    using Validators;

    /// <inheritdoc />
    /// <summary>
    /// Type responsible for processing the main workflow
    /// </summary>
    public class ProcessFileData : IProcessFileData
    {
        /// <summary>
        /// Instance of IArgumentValidator
        /// </summary>
        private readonly IArgumentValidator _argumentValidator;

        /// <summary>
        /// Instance of IFileDetails
        /// </summary>
        private readonly IFileDetails _fileDetails;

        /// <summary>
        /// ProcessFileData constructor
        /// </summary>
        /// <param name="argumentValidator">Instance of IArgumentValidator</param>
        /// <param name="fileDetails">Instance of IFileDetails</param>
        public ProcessFileData(IArgumentValidator argumentValidator, IFileDetails fileDetails)
        {
            _argumentValidator = argumentValidator ?? throw new ArgumentNullException(nameof(argumentValidator));
            _fileDetails = fileDetails ?? throw new ArgumentNullException(nameof(fileDetails));
        }

        /// <inheritdoc />
        /// <summary>
        /// Method to process the main workflow
        /// </summary>
        /// <param name="args">Command line arguments</param>
        /// <returns>Main workflow output to pass to console</returns>
        public string Process(string[] args)
        {
            string consoleOutput;

            try
            {
                _argumentValidator.ValidateNumberOfArguments(args);
                var function = args[0];
                var filePath = args[1];
                _argumentValidator.ValidateFileName(filePath);
                var functionType = _argumentValidator.ValidateFunction(function);
                
                switch (functionType)
                {
                    case FunctionType.Size:
                        consoleOutput = "File name: " + filePath + " - File Size: " + _fileDetails.Size(filePath);
                        break;
                    case FunctionType.Version:
                        consoleOutput = "File name: " + filePath + " - File Version: " + _fileDetails.Version(filePath);
                        break;
                    default:
                        consoleOutput = "Unable to process invalid function type: " + functionType;
                        break;
                }
            }
            catch (Exception ex)
            {
                consoleOutput = "Unable to process instruction, encountered error: " + ex.Message;
            }

            return consoleOutput;
        }
    }
}
