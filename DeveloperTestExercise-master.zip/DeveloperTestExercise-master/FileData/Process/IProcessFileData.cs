﻿namespace FileData.Process
{
    /// <summary>
    /// Interface for the ProcessFileData type
    /// </summary>
    public interface IProcessFileData
    {
        /// <summary>
        /// Method to process the main workflow
        /// </summary>
        /// <param name="args">Command line arguments</param>
        /// <returns>Main workflow output to pass to console</returns>
        string Process(string[] args);
    }
}
