﻿namespace FileData
{
    using Process;
    using Tools;
    using Validators;
    using System;
    using System.Diagnostics.CodeAnalysis; 
    using Unity;
    using Unity.RegistrationByConvention;

    /// <summary>
    /// Main program entry point for FileData demonstration
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class Program
    {
        /// <summary>
        /// Instance of unity container used for managed object lifetime creation
        /// </summary>
        private static readonly IUnityContainer Container = new UnityContainer();

        /// <summary>
        /// Main entry point for the console application
        /// </summary>
        /// <param name="args">array of console arguments</param>
        public static void Main(string[] args)
        {
            var numberOfExpectedArguments = 2;
            var validFileNameRegex = @"^[\w\-\. ]+$";
            var validFunctionRegex = @"^(-s|--s|\/s|--size|-v|--v|\/v|--version)$";

            BuildUnityContainer(numberOfExpectedArguments, validFileNameRegex, validFunctionRegex);
            var processFileData = Container.Resolve<IProcessFileData>();
            Console.WriteLine(processFileData.Process(args));

            Console.WriteLine("Press any key to end program.");
            Console.ReadKey();
        }

        /// <summary>
        /// Private method to build a simple unity container to encourage use of SOLID design principles
        /// </summary>
        private static void BuildUnityContainer(int numberOfExpectedArguments, string validFileNameRegex, string validFunctionRegex)
        {
            Container.RegisterTypes(AllClasses.FromLoadedAssemblies(), WithMappings.FromMatchingInterface,
                WithName.Default, WithLifetime.ContainerControlled);

            Container.RegisterInstance(typeof(IArgumentValidator), new ArgumentValidator(numberOfExpectedArguments, validFileNameRegex, validFunctionRegex));
            Container.RegisterInstance(typeof(IFileDetails), new FileDataDetails());

            Container.RegisterInstance(typeof(IProcessFileData), new ProcessFileData(Container.Resolve<IArgumentValidator>(), Container.Resolve<IFileDetails>()));
        }
    }
}
