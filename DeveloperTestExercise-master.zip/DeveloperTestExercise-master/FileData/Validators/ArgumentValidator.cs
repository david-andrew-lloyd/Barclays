﻿namespace FileData.Validators
{
    using Enums;
    using System;
    using System.IO;
    using System.Text.RegularExpressions;

    /// <inheritdoc />
    /// <summary>
    /// ArgumentValidator to check the form of filenames and console arguments
    /// </summary>
    public class ArgumentValidator : IArgumentValidator
    {
        /// <summary>
        /// Injected number of arguments that should match expectations
        /// </summary>
        private readonly int _numberOfExpectedArguments;

        /// <summary>
        /// Injected filename regex for the valid filename
        /// </summary>
        private readonly string _validFilenameRegex;

        /// <summary>
        /// Injected function regex to match expectations for arguments into the application
        /// </summary>
        private readonly string _validFunctionRegex;

        /// <summary>
        /// ArgumentValidator class constructor
        /// </summary>
        /// <param name="numberOfExpectedArguments">The number of expected arguments</param>
        /// <param name="validFilenameRegex">The valid filename regex</param>
        /// <param name="validFunctionRegex">The valid function argument regex</param>
        public ArgumentValidator(int numberOfExpectedArguments, string validFilenameRegex, string validFunctionRegex)
        {
            if (numberOfExpectedArguments < 0)
                throw new ArgumentException("numberOfExpectedArguments cannot be less than zero: " + numberOfExpectedArguments);

            _validFilenameRegex = validFilenameRegex ?? throw new ArgumentNullException(nameof(validFilenameRegex));
            _validFunctionRegex = validFunctionRegex ?? throw new ArgumentNullException(nameof(validFunctionRegex));

            _numberOfExpectedArguments = numberOfExpectedArguments;
        }

        /// <inheritdoc />
        /// <summary>
        /// Method that validates number of command line arguments
        /// </summary>
        /// <param name="arguments">Command line arguments</param>
        public void ValidateNumberOfArguments(string[] arguments)
        {
            if (arguments == null)
                throw new ArgumentNullException(nameof(arguments));

            var numberOfArguments = arguments.GetLength(0);
            if (numberOfArguments != _numberOfExpectedArguments)
                throw new ArgumentException("Invalid number of expected arguments, expecting: " +
                                            _numberOfExpectedArguments + " received: " + numberOfArguments);
        }

        /// <inheritdoc />
        /// <summary>
        /// Method that validates a given filename to a supplied regex
        /// </summary>
        /// <param name="filePath">The full filename</param>
        public void ValidateFileName(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentNullException(nameof(filePath));

            var invalidPathChars = Path.GetInvalidPathChars();
            if (filePath.IndexOfAny(invalidPathChars) != -1)
            {
                throw new ArgumentException("fileName contains invalid characters: " + filePath);
            }

            var fileName = Path.GetFileName(filePath);
            if (!RegexMatch(_validFilenameRegex, fileName, out _))
            {
                throw new ArgumentException("filename does not appear to be in correct format: " + filePath);
            }
        }

        /// <inheritdoc />
        /// <summary>
        /// Method that validates command line arguments for the given function 
        /// i.e version or size
        /// </summary>
        /// <param name="function">The function supplied via the command line</param>
        /// <returns>FunctionType</returns>
        public FunctionType ValidateFunction(string function)
        {
            if (string.IsNullOrEmpty(function))         
                throw new ArgumentNullException(nameof(function));

            if (!RegexMatch(_validFunctionRegex, function, out string functionMatchGroup))
            {
                throw new ArgumentException("Unknown function: " + function);
            }

            switch (functionMatchGroup)
            {
                case "s":
                case "size":
                    return FunctionType.Size;
                case "v":
                case "version":
                    return FunctionType.Version;
                default:
                    return FunctionType.Unknown;
            }            
        }

        /// <summary>
        /// Private method for performing regex matching, note this is private
        /// and the given parameters are not validated thus the expectation is 
        /// that the public methods will be performing this operation
        /// </summary>
        /// <param name="regularExpression">The given regular expression</param>
        /// <param name="artefact">The string we are validating against artefact</param>
        /// <param name="functionType">In this case we expect functionType otherwise string.empty for the filename validation</param>
        /// <returns></returns>
        private static bool RegexMatch(string regularExpression, string artefact, out string functionType)
        {
            var regex = new Regex(regularExpression, RegexOptions.Compiled);
            var match = regex.Match(artefact);
            var matchSuccess = match.Success;
            if (matchSuccess)
            {
                foreach (var group in match.Groups)
                {
                    char[] charsToTrim = { '-', '/' };
                    functionType = group.ToString().Trim(charsToTrim);
                    if (functionType == "s" || functionType == "v" ||
                        functionType == "size" || functionType == "version")
                    {
                        return true;
                     }
                }
            }

            functionType = string.Empty;
            return matchSuccess;
        }
    }
}
