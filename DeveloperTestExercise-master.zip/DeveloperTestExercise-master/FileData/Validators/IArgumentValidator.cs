﻿namespace FileData.Validators
{
    using Enums;

    /// <summary>
    /// Interface for the ArgumentValidator
    /// </summary>
    public interface IArgumentValidator
    {
        /// <summary>
        /// Method that validates number of command line arguments
        /// </summary>
        /// <param name="arguments">Command line arguments</param>
        void ValidateNumberOfArguments(string[] arguments);

        /// <summary>
        /// Method that validates a given filename to a supplied regex
        /// </summary>
        /// <param name="filePath">The full filename</param>
        void ValidateFileName(string fileName);

        /// <summary>
        /// Method that validates command line arguments for the given function 
        /// i.e version or size
        /// </summary>
        /// <param name="function">The function supplied via the command line</param>
        /// <returns>FunctionType</returns>
        FunctionType ValidateFunction(string function);
    }
}
